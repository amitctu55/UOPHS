<?php include ("assets/includes/header.php"); ?>
<?php include ("assets/includes/leftmenu.php"); ?>
        <div class="pag_cstm">
         
          <div class="row">
		   <div class="col-lg-12">
              <div class="pag_cstm_panel">
                <div class="pag_cstm_panel_panel_ontent p-t-0">
                  <div class="row paddb40">
                
				
				
					
					

            
                               	<div class="col-sm-5 processs">
								<h4>Great Progress!</h4>
								<p class="process">Your profile is just few steps away from going live.</p>
								
								<p class="step1">Section A: Profile Details</p>
								<p class="process">Doctor’s basic details, medical registration, education qualification, clinic details etc.</p>
				<a href="registration_step2.php"><i class="fa fa-check-square-o" aria-hidden="true"></i>
Change Profile</a>

							<div class="step2 border1">
							<p class="step2">Section B: Profile verification</p>	
						<p class="process2">Doctor identity proof, registration proof, clinic ownership proof etc.</p>
								<a href="identity_proof_submit.php"><i class="fa fa-check-square-o" aria-hidden="true"></i>	Change Profile</a>
						</div>
						<div class="step2 border1">
							<p class="step2">Step C: Start getting patients</p>	
						<p class="process2">Location, Timings, Fees</p>
						<a href="map_location_step3.php"><button class="continue">Continue</button></a>
						
						</div>
						
						<br/>
						<div class="step3">
						<p>Basic details about your practice helps patients reach you easily for appointment booking and inquiries.</p>
						</div>
				</div>
					
			<div class="col-sm-7">
				<img src="assets/images/upachar.jpg" class="img-responsive"/>
                        </div>        
                                
                           

                        </div>  
						 </div>  
				   </div>
                </div>
              </div>
            </div>
        
         
          			<?php include ("assets/includes/footer.php"); ?>